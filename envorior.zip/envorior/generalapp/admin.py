from django.contrib import admin
from generalapp.models import User

# Register your models here.

admin.site.register(User)